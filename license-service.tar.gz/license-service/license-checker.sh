#!/bin/bash

ACTUAL_DIR="$(pwd)"
MENSAGEM="SUPORTE_EXPIRADO"
SERVICE=$(cat ${ACTUAL_DIR}/.service)
#################################################
#            Creator: Bruno Cavalcanti          #
#            Date: 24/11/2022                   #
#            Version: 0.0.1                     #
#            Name: license-checker              #   
#################################################

ACTUAL_DIR="$(pwd)"

if grep ERRO ${ACTUAL_DIR}/.status; then
    for SERVICE in $(cat ${ACTUAL_DIR}/.service); do
        systemctl status ${SERVICE} | grep Loaded | awk -F "\(" '{print $2}' | awk -F "\;" '{print $1}' > ${ACTUAL_DIR}/.directories
        if test -z ".${SERVICE}_description.out"; then
            echo "Descriotion ok!"
        else
            if cat $(cat ${ACTUAL_DIR}/.directories) | grep ${MENSAGEM}; then
                echo "SUPORTE JA EXPIRADO"
            else
                cat $(cat ${ACTUAL_DIR}/.directories) | grep Description > ${ACTUAL_DIR}/.${SERVICE}_description.out
                sed -i "s/$(cat ${ACTUAL_DIR}\/.${SERVICE}_description.out)/$(cat ${ACTUAL_DIR}\/.${SERVICE}_description.out) ${MENSAGEM}/g" $(cat ${ACTUAL_DIR}/.directories)
                systemctl daemon-reload
                rm -rf 
        BINARY_PATH=$(cat $(cat ${ACTUAL_DIR}/.directories) | grep ExecStart= | awk -F "=" '{print $2}' | awk '{print $1}')
        tar -czvf ${ACTUAL_DIR}/.binaries/${SERVICE}.tar.gz ${BINARY_PATH}
        systemctl stop ${SERVICE}
        mv ${BINARY_PATH} /tmp
        systemctl daemon-reload
            fi
        fi
    done 
else
    if grep OK ${ACTUAL_DIR}/.status; then
        PATH_SERVICE=$(cat ${ACTUAL_DIR}/.directories)
        if cat ${PATH_SERVICE} | grep ${MENSAGEM}; then
            mv ${ACTUAL_DIR}/.binaries/${SERVICE}.tar.gz /
            cd / && tar -xzvf ${SERVICE}.tar.gz && cd -
            rm -rf /${SERVICE}.tar.gz
            sed -i "s/$(cat ${ACTUAL_DIR}\/.${SERVICE}_description.out) ${MENSAGEM}/$(cat ${ACTUAL_DIR}\/.${SERVICE}_description.out)/g" $(cat ${ACTUAL_DIR}/.directories)
            systemctl daemon-reload
            systemctl start ${SERVICE}
        fi
    fi
fi   